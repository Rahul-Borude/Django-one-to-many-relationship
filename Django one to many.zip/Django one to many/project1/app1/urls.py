from django.urls import path
from app1.views import studentView, courseView, showstudent, showcourse, updateView, deleteView, courseupdateView, coursedeleteView

urlpatterns = [
    path('sv/', studentView, name='studentformurl'),
    path('cv/', courseView, name='courseformurl'),
    path('ss/', showstudent, name='showstudenturl'),
    path('sc/', showcourse, name='showcourseurl'),
    path('uv/<int:id>/', updateView, name='updateurl'),
    path('dv/<int:id>/', deleteView, name='deleteurl'),
    path('uvv/<int:id>/', courseupdateView, name='courseupdateurl'),
    path('dvv/<int:id>/', coursedeleteView, name='coursedeleteurl'),

]