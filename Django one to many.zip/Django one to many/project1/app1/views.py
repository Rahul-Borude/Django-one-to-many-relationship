from django.shortcuts import render, redirect
from app1.models import Student, Courses
from app1.forms import StudentForm, CourseForm
# Create your views here.

def studentView(request):
    form = StudentForm()
    template_name = "app1/studentform.html"
    context = {'form':form}
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def courseView(request):
    form = CourseForm()
    template_name = "app1/courseform.html"
    context = {'form':form}
    if request.method == "POST":
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, template_name, context)

def showstudent(request):
    obj = Student.objects.all()
    template_name = 'app1/showstudent.html'
    context = {'student':obj}
    return render(request, template_name, context)

def showcourse(request):
    obj = Courses.objects.all()
    template_name = 'app1/showcourse.html'
    context = {'course':obj}
    return render(request, template_name, context)

def updateView(request, id):
    obj = Student.objects.get(rn = id)
    form = StudentForm(instance=obj)
    template_name = "app1/studentform.html"
    if request.method == "POST":
        form = StudentForm(request.POST, instance=obj)
        print
        if form.is_valid():
            form.save()
            return redirect('showstudenturl')
    context = {'form':form}
    return render(request, template_name, context)

def deleteView(request, id):
    obj = Student.objects.get(rn = id)
    template_name = "app1/confirmation.html"
    context = {'data':obj}
    if request.method == "POST":
        obj.delete()
        return redirect('showstudenturl')
    return render(request, template_name, context)

def courseupdateView(request, id):
    obj = Courses.objects.get(id = id)
    form = CourseForm(instance=obj)
    template_name = "app1/courseform.html"
    if request.method == "POST":
        form = CourseForm(request.POST, instance=obj)
        print
        if form.is_valid():
            form.save()
            return redirect('showcourseurl')
    context = {'form':form}
    return render(request, template_name, context)

def coursedeleteView(request, id):
    obj = Courses.objects.get(id = id)
    template_name = "app1/confirmation.html"
    context = {'data':obj}
    if request.method == "POST":
        obj.delete()
        return redirect('showcourseurl')
    return render(request, template_name, context)