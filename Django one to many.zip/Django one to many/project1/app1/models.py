from django.db import models

# Create your models here.
class Student(models.Model):
    rn = models.IntegerField(primary_key= True)
    fname = models.CharField(max_length= 100)
    lname = models.CharField(max_length= 100)
    city = models.CharField(max_length= 100)

    def __str__(self):
        return self.fname

class Courses(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.CharField(max_length= 100)

    def __str__(self):
        return self.student