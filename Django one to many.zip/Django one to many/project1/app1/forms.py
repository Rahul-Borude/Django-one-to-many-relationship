from django import forms
from app1.models import Student, Courses

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = "__all__"
    
class CourseForm(forms.ModelForm):
    class Meta:
        model = Courses
        fields = "__all__"